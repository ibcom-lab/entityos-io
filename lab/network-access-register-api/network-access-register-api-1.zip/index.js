'use strict';

const fs = require('fs');
const path = require('path');

// ── Config ──────────────────────────────────────────────────────────────────
const SETTINGS_PATH = path.join(__dirname, 'settings.json');
const DATA_STORE_PATH = process.env.DATA_STORE_PATH || '/tmp/ip-records.json';

// ── Helpers ──────────────────────────────────────────────────────────────────
function loadSettings() {
  const raw = fs.readFileSync(SETTINGS_PATH, 'utf-8');
  return JSON.parse(raw);
}

function loadRecords() {
  if (!fs.existsSync(DATA_STORE_PATH)) return [];
  try {
    return JSON.parse(fs.readFileSync(DATA_STORE_PATH, 'utf-8'));
  } catch {
    return [];
  }
}

function saveRecords(records) {
  fs.writeFileSync(DATA_STORE_PATH, JSON.stringify(records, null, 2), 'utf-8');
}

function isValidIP(ip) {
  // IPv4 or IPv6
  const ipv4 = /^(25[0-5]|2[0-4]\d|[01]?\d\d?)(\.(25[0-5]|2[0-4]\d|[01]?\d\d?)){3}$/;
  const ipv6 = /^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$|^::([0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}$|^([0-9a-fA-F]{1,4}:){1,7}:$/;
  return ipv4.test(ip) || ipv6.test(ip);
}

function isValidGuid(guid) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(guid);
}

// ── HTML Page ────────────────────────────────────────────────────────────────
const LOGO_B64 = 'iVBORw0KGgoAAAANSUhEUgAABLAAAAEmCAYAAAByJmk2AAAACXBIWXMAAAsSAAALEgHS3X78AAAgAElEQVR4nO3dTXIbRxKG4faE99TwACC9wlL0DjtBJxB8AAShPSMEn0DUCQxFYC8wcACDJxC4407kEisTOABGOIEnisq2WxRI4qeqMqv6fSIY8sx4xAbQ6J+vM7N++vvvvwsAAAAAAADAqv/wyQAAAAAAAMCyn/l04DS7i+OiKI7lP7Yrb0r7wRv0aoc3bFUUxU3lP3+t/OfqP9/Mxo2vfCAAAAAAAKCKFsIaaXYXJxJSlX+WP0fG3oXbSrDl/pwWRXE3GzfuDGwbAAAAAACIjAArQ83u4oWEVO1KYPUyk1d6JcHWnVRsTQ1sEwAAAAAACIgAKwNSWVUGVjmFVZu6lSotF2xNqdQCAAAAACAvBFgJksCqXfk5qPt78sBcAq0pgRYAAAAAAOkjwEqAtAS6oKojf1qbWWXdbSXMmtT9zQAAAAAAIDUEWEbJqoBlYPWm7u+HRysJs1yQNWHVQwAAAAAA7CPAMqQSWvVqOMdKyyVhFgAAAAAAthFgKZP2QBda9Qmt1Lkwa0SbIQAAAAAAthBgKWl2Fx0Jrk5r+QbYtpKqrMFs3Lip+5sBAAAAAIA2AqyIpNqqLy2CDGJPgxsAP6DFEAAAAAAAPQRYETS7i7aEVlRbpausyjqfjRt3dX8zAAAAAACIiQAroGZ30ZPg6lW2L7KeriTImtb9jQAAAAAAIAYCLM8qQ9nPaRPM3q3MyRrV/Y0AAAAAACAkAixPKvOt3M9BFi8Km5pLRRZBFgAAAAAAARBg7YngChUEWQAAAAAABECAtYdmd3FOcIU1CLIAAAAAAPCIAGsHMpydGVd4jguyegx7BwAAAABgPwRYW2h2F203tLsoipfJbDQscKsW9mfjxg2fBgAAAAAA2yPA2kCzuziW4OqN+Y2FZRcSZH3lUwIAAAAAYHMEWE+oDGh/b3YjkZqVzMca8MkBAAAAALAZAqxHSLvgiDlXCORW5mPRVggAAAAAwDMIsB6QqqsR7YKI5KNUZNFWCAAAAADAIwiwKprdRUfCqwMzG4U6YLVCAAAAAACeQIBF1RXsoBoLAAAAAIA1ah9gUXUFY6jGAgAAAADggdoGWFRdwbiPs3Gjz4cEAAAAAEBNA6xmd3FSFMWEFQZhHCsVAgAAAABqz/lP3d6FZndxXhTFF8IrJOBlURTTZnfR48MCAAAAANRZbSqwpGXQVV29MrA5lrmqHzdE/Eb+dKrzmG62HTLe7C6Oi6I4lv/oPocT+efjyg+B4tMuiqLoM+AdAAAAAFBHtQiwaBn8wUoCKvdzV/6zdjgin5MLuNoSbJ1IFRK+ceFiZzZu3PF+AAAAAADqJPsAS9qvPhnYFE1XUkVVBlVJBSASbJ1IsFX3UGslc7EmBrYFAAAAAIAosg6wmt2FW2Xw1MCmxFYGVtPZuDG1tWn7k3bQduWnjoHW77NxY2BgOwAAAAAACC7LAKuG867m8nqndazMkRlbLsjqyJ8HBjYrBuZiAQAAAABqIbsAS9rNRjWoyrmV1+lCqxsD22NGs7voSJjVqUGY5faDNiEWAAAAACBnWQVYEl5NMw4t5hJajRjkvZmahFlzGe5OkAkAAAAAyFI2AVbGw9pX0h44IKDYj+wjLsh6k/LreMRKKrHYRwAAAAAA2ckiwMo0vHKtYW5I94T2ML9kZpbbZ/qZVWWtZCbWyMC2AAAAAADgTfIBVrO7cCHPOwOb4suFtAhmt3qgRRJ+9jObmfaWEAsAAAAAkJOkA6xmd+Fu0k8NbMq+VjLbasBsKx3N7qItQVYu7YWEWAAAAACAbCQbYGUSXq2kTXBAm6AN0l54nkkw+vts3BgY2A4AAAAAAPaSZICVQXhFcGVcRkHWxWzc6BnYDgAAAAAAdpZcgJVBePWB4CodEmQNEm8tJMQCACSn2V2cyOrBrs3/ZM3CK/OiKNzqu1NZ9IYxDAAAZCypACvx8MoNZz/n4ipNMiPLVWS9SvQlEGIBAJLQ7C46cs7ddoGVK7nWYiEcAAAylEyAlXB4xcVURmTVQndRfZTgq2KwOwDALKl6Hnl4WHRZFEWPancAAPKSRICVaHjl5lz1CQzy0+wuXsiKhe8TfHGEWAAAc+QB0WBNm+Cu3HVYezZu3PBpAwCQB/MBVrO7cBcz7wxsyjY+StUVT/4y5vFJcWyEWAAAMyS8+hRoezjnAQCQCdMBVuALmhDmUrJOu2CNNLuLvrQV+npqHMNvs3FjUvfPDgCgK9K13q9UYgEAkD6zAVaC4RVVVzUmbYWjhFYrpLUCAKBKVhn8EmEb3DnvmGs0AADSZjLAinhB4wNVV/hHYtVYhFgAADXN7uJmh5UGd3U5Gzc6fNoAAKTLXIAl4dU0kQDgQga11+KJnnw2Lyr/1bH8rOMuSqvvy9e6BCUyG2sS8aJ8H7cSYvFUGgAQjVKl/WseOAIAkC5TAZa0YbmQ48jA5jxlJVVXWc0QanYX7UooVf3x/XncSrh1U/nzLreAq9ldnCeyUuHtbNw4MbAdAICaaHYXdwrXe1ezcaPNPgYAQJqsBVgxS8l35cKXzmzcuDO+nU+SsMr9nEhQZeV9v5VAy/1MUw+15H2eJFBReDEbN3oGtgMAkLlmd+Fa+f5UepW/pH4NBwBAXZkJsJrdhRuAfWpgU56SbMtgJbByP68MbNKmVhJmTVINtKSycJpAOPv7bNwYGNgOAEDGlK/5ONcBAJAoEwFWIisOvp2NGyMD27ERmcPkwqpOQivjbWJVhlnuz5TCxERCWuaDAACCUmofLNFGCABAotQDrARWHExmpTYJrVxg1UtkgLgPlxJoJRFmJRDWuv39hPYKAEAIUpX8P8U3dzUbN15s8O8BAABjVAMsuYi5MzwfyPy8K3kPOxlWWu3iQoIs08P1E5iLxVB3AEAQcg78rPnuzsaNn/h0AYTUWg6rq7dvW/VZLnT19frwrBaruON7reWwutp/dV/a1J38ODfXh2fZrDivHWBNDc9jupXKK5MftlRbnUtwZX1AeGzzoihcu97IavgolYcTwytufpyNG30D2wEAyIiFAItB7gB8aS2H1UWxTuTH971ZORO4DCWmuYUSdbVm/zkOeH94K8HoVPajmxQDUrUAq9lduPDlvcovf57ZFdlk5Z5+YoPYNV1IkGVurlMCw91/s17NBgBICwEWgFS1lsOy8+VEqqq0r+HnZZjl/qRayzapqioXVTsxdA94VQlFzd/7qQRYRi5eHmMyvJLZSeeGK3asc1/Mc2tBloRYE6OBJPOwAABe0UIIICXSCtgzElg9pwy0JhJoUaGlLLH9p3RZ7kfXh2fm7gOjB1hyw35jNIj5MBs3zg1sxz8IrryzGmRZXaGQ1ZoAAN7ICIS/NN9RAiwAT6mEDp3E78EuJYRIZiX9HEilVT+D/aeQe+eR7EcmAlGNAGtidNj429m4YebLTXAVnLkgy3CIZS7YBQCkq9ldfFWc38mDGQA/kPbAngQPud1/raQqa0CbYTit5bAn+1COo37KfehcuyoraoAlocynaL9wc2bCKymtHyRUYpg6F2T1rLTJGQ6xfp2NG5zwAGAHsnDHtisI+XBjcTEa5YeZ0Rcpkaqz4w3+Vd/uGAMAPE2qrfpGr79DuJUgi6osTyS4qlPhyaXsQyqFINECLDl53xhcMc9EeCXvz8BodVodfJSKLPULfaMhFk+sAWBHiqsuvza6iInmA83o74niwkVUUAOPkNXfzmu8MNZK7j0HzMraTQ2Dq4fuC0FiV2T9J+LvGhFerScXNjeEV6reuSeVclGtShYRuDD2/ryS6kAAAPY1kZun2OYWAz0A8bjgqrUcTmUxiTqv6n4gwfpdazk8lxZKbED2oTt5EFPncT/u+/NXazkcxNx/ogRYze6ib/AA8bt2eOUCgWZ3cSMHD2vhXh25z+CTe1IuFXFqjIZY5lbnBACkR6qdBwobTjUSUFMEV4/6Lsgyuo0muJCmtRxOZB9iTvW/3sn+04nxy4IHWBIEWPsyXMzGDY0Lp3tuJcZmdzGQnZ9ZV/a4k9qNBK9qJMS6MvTuRDkoAQBqYRC5CmtuabEeAHFI6DAiuHrWfZDlKotiBREpkffkjo6pR7n9508X8IWuxopRgTUwVl10IcGAChnkOpWkEna5ffYPA9VYHRm2aMGB7L8AAOxFqrBiXo9xQwbUTGs57EvoUJcB7T4cSRAxbS2Hqh0pVrgWOfee0DG1ERfw3cjiCEEEDbCa3UXHWEp5pRxeuYPoF6quklJWY6lc+MoFvps9NTfypnEiAwB4MRs3JpHa5d+yki5QH+7mubUcuu/8H4QOOyvnG9W2rVCq924oPNmaC0G/yJB774IFWK5NTmm+wWNutZ6+ScvgRA6iSM99SaRbHVD266gkxOooDbx9iAosAIA3EWY+XtA6CNSHBC4UDPjj2gqDVtRYJK/3jv1oL59CBKAhK7D6hoabuRv/jgQBUUnLFSsM5sGVH6u0FMqTY9ofAADZCRhi/a5ZeQ8gHtfuJtUy73nbvXMhzlRaMrMn4dWU6j0v3ssMOm+CBFhyg2/p4NGejRt3sX9ps7voyRMAVinIx0tpKWzHfkWy9PfbjN9bAEBNSdD01lO1sWu7f625YA+AeGTA9g3VMkHdzweOMaRbE+FVEKc+Q6xQFViWSrVV5h7IKoOfYv9eROEOaJ8loIxK2iBizAt5DDNEAABByDnueI/znAu/Prh2d3noAyBzDNiOLviQbi2EV0F5C7G8B1hSmWJlidLocw8q864Y9pa/T24uVuxXKU+ptVYmjF7JCACoDzfuQc5z/3UtgG4BnmdevAutLqV663g2bpxrjIwAEJcM2GZldx1H0lKYTYu2VJURXoV16mOf+TnAJlqpvrqNPfdABnxPKV+tldNmd+Febz/yBXNbwqSYB9kVqzgBAGKQc+qgXBBIZoo+bFv5ynkJqB+plBkleM+1eqKb4SSx8ORAhnQfXx+eJb1SYWLh1fyJgoLjBEYXuX3m6/Xh2WTXv8BrgCUtVRbetFXsgdcy92tCeFVLbrj7ias+jBViud/T7C7cPv454hu+84EGAIB9EFQBKNJo87qSgOFOtrO4PjzbqqVZXuMLeWD9QsItKx1OD72XECvlaqyBoXv4Kwk5v+66/xSyqIEEWuVP21BIOnL7+PXh2U6dPd4CLKk+sjIssxdzaLs8FaTksN5eygqFMUMs9/s+RFwwIemnKwAAAEiXtB8NjN1zXcl94HSXoGGd68OzMrD/7u+TYKtd+bHyPrjWsCLFEEsWADhV+vWrct+R/cfbgxoJh37IQx7sQ298/b4tHUhhxE5z1H76+++/vWxFs7s4N7Ly4MfZuBFtiU/CKzxwK6teRmsnbHYXMVZduZyNG1GrGgEgF83uYqr09Pw1w8z1KV4jf3Azway9H8AuJLyysEDWSm6+JxI6qM3cay2Hbek66hjpgrq/D9J8T7YhrYOxR7IUslDJZJ82Ol/ke9VRCrM+7NJ+6mWIu1RfRQuNnnAbs0qE8AprlJVYMZeX7XhadvwxKyPfbwAAANSMkfDqqlwswlUaufBBO6hxFV/Xh2f968Mz1yL2Wnml8qK8D5JgKAUxq/nmsjDJf8v9x8L7c304Nro+PHP3kr+4QqDA95QPvZdWx634aiHsGwlxerEqX2ocXt1KT25R6e9epzpsNYWBcj5FbSd07bLN7qIf8MTej9mSCwAAABQ2wisXCp3vOq8nFmlfdOGRuyfoyf25xv3XS7lH3qk9LBapXovROnhfCOCCIhuvfD3Zv/ut5fBcCoJire45knbGje3dQiiVJhqldw9FK5OuQXhVrpAxrYRUN/uGMTLo/lgOaMfGBxL6ELWdUBZR8H2CfzsbN0wfcAHAOloI640WQmA3iuHVSqpzRtaDq6fI+3euFGRdWJ6J1VoOY5yXP0r4mURLZZXMyhpEunb5bZuKNB8VWBaqr24jhlcvJCnMKbyaVwfIhaq2kb/37uFAQgkELQ4k3FfsSqxRs7soPJ7oCa8AAAAQXeUGOrYkKq42IVU/I6Ugy+xgd6m+ChnMuAC042uovwYZKN+WiqzQD2AG26x2v9cMLEOzr6J8MeT1Tg0ts7mPW+nD/XU2bhzPxg3XfjnSaBVzS2PPxo2BGxI+GzdeSA/3RwnWUvcy5slXAqdf5fPd1Vye2hNeAQAAICoJr2J3u7gZV7/KfKKsRmdIkOXe0w+Rf/WpBCDWhNymW5mTlkX1swxZfx14NtaRhKwb2bcCy0L1lVt10NuSk88YJR5ezeU1qARVm5J2B/fTl+qsvgwqT7Uy69RVRrmQMMYvk+/DibQU9rfYZ93+cU5whcdIiF+dafBYz/pNdVYeM9TyJMfnctbhun2huh/s3YYOAMifDACfRLzuT2JG0b6kje28tRyO5H4wVlu7G9R9Z+X9lXA01Gu/dIU1KbYMPsWFcVK1FjJU7st++ay9ZmA1u4uvyqGCu+E+iXFR3OwuRpEGvYVwIaFV0knwDoGMNSoteQ9aNMsA4kCeNBVyMJpEDIJhnMyrO6n8HHv43pWz9e7kzxtm86TDtULLMaTcL3ZtQ7it7APTuuwDzMCqN2ZgAZtrLYc3Ea/1swwcNiHD3s8j3cu7a8C2tKWpkgAvxD397fXhmenB9fuKUBn5epPKtZ0DrEADo7f122zcCL4EpZHXuq2VpJiD3Kof5EbKHXTfGNicbXEzAXOksqpTCTpjzki4fTCDjyodI+Tc14kwm/BKnrZPcq3WI8CqNwIsYDMBw4WHalF19ZzWcngs598YgeF94Yl2WNhaDkMU4NxKQJf9NWzgEGujwf/7BFh3SisalK5m48ZWSy7uQqpXvoT+PR6Vq2YMcr8RlCqR88Qq41ZSNUhLFVTJ96cjMwQtVTVeVsKMLI5h8l7HHmK6U3WTbGu5BLdGhfVtpdXd3Ocvod7xDv/XntYqUFLx5pOXMQQS6kS3T6BTqUTcVuiBwY+5erhwjgdPHlv2eI98ybqifI9jkC/BxpBEXHHwVqqu6DwQEYPDq+vDM7XjQ2s5dNe9f3r+a81Ul8Ui7YSfA/26/z4XBO40A0tOTprhVRFjeHxlaHsq3IVqvy4VDHIC7TW7i0HEZT73dSA351mXmMKuSlWN1QrGN/LzqdldXMrNSOpPSI+Vqi82Pn8ZeiDgwtQ/3LY0u4uJzOWzFPj3EjnXlEJ8nlNPoZjGd6LYc3hvW3G7d/Eq0P763LFF8z06kXNcduS+RLsjJMj5OOKKg7VtGXyKq3ppLYfTCPvXK9e6eH14prG6ZBHo2DCoWxgqM7E+BDrWd547zuy6CqH2yoMXkZ6uxBwguA/3hO0XWUmwdgdkWcWwLSskpLBy4UsJ3YAo3EWvq3aQytlPCbXflkHWnWz/iw3+P9iC7BvuQuEvY9WsB7I9f7ntk4ANgHFSnaV5LfYm43OFdjB3GfCBwijCPZdrT+oQXq0n7ZS/Bl5tzvlDAksNvr9Dc1mlr3bkde+z6v1jnv2Mtq7AkotIzZufVaTqq/MEnrK696IXYw5YCuSi6Vhx1sQ23rmZKCl9drIqTDnAubw4dBcyd7ksFZsbA+1gvhzJd/p9s7u4MFiVk6RmdxFzgOs+TmU11w91aI8HMjCQSkotzz7BT5R2gBXkmrW1HA4ijDJ4W/d5V5twlUQRVpsr5PsZNcSS0Mz3a6r7jMF+gFbCN+6e86mgeZcKLO3qq+AXrzL3ynoA4m7ijgmvfiTzLX4NlAr7NLL+lNAdQFypr6wI8z85SP1RhglSzfO5tRz+3VoOJzK/AMrKiitZ6e1d4uHVQ2VVzoCKrN24YFOGiv+R2L7hjjk3ze4iy/YgICPa16bZHSPkfKdaQBCinV/Ckne+/94HCK+2IO1wJ4Hvo162lsPY4Y/v2Vvzuu9XUsBwtcG/uq0nP6tdAizNG9RV6P5oOUFYDoVWsvpiLdsFNyVthe7g+8HwZh5Y3tfkxHInN7mbPBm7b/dqLYd3MiQRCqSq5k5u9nMKrh5yF7x38nqxIZlheZPYHKcqV433p7QVEmACBkmF7KXiluXYRphd9ZVU9ocOAAivdnB9eHYnIULIEOt95FZC37+LcTDfhAgi/QVYMvxX84YoRuvAuYEB9Y+5oupqO1KNZXk21itrN+BuSV2puNo1ALm/wXQrmsjFCSJwlaPN7uImwaqafbjX+Yd73VI5iyfIseZzJvuHq8Sb8rkDZlGF5Zf26wlxs94PfM9FeLUHaeHqBJ6JFfPz8T1Lk/vxcFVYXiuwNA+eMaqvYpSx7uqjG1RO1dX2ZDbWSaASRx/OrQwolichN55mEdzfYBJihSftgl8izJCwyr3uL1rL8qdABrVrzqQJ4aWEWJpL9gNYQ9rNQg+Dfko2AZaB9sG578Wz5Hoz5LgWwisPKpVYob7LrpUw1oN8n5Xnc3lv8I3v79qT9zMbB1gGhrfHqL6yeKBzB4y3s3GDNpk9uH1HVir8aHDzDizse67yKsDQxpeEWOFUqq5SWtY9pPdUY/1IwitLKwz65I5Xn6VCHIAtmhUKObUR5lh9FbIo4SPhlT8yEyvkg6Lz0PcJAf5+Fq/6XogW40f3uW0qsHKvvrLYOuhedzvE0MS6kiDwrcGX/8rAYOJJoNail6zS4Z/csE9rXHX1mLIqh0Aj//Cq6hOfOWCO9oyYXKqwspp/JXNSQ81hvLg+POOhv2cSYoW6fzqIcJ/g+8Gm14rE1Em7qe+5h492J20TYGleGAatvpLqMmsVDG5o3onvkl38U9b+m3Jp+zpqQ4llYHvIIOTdU0k6tiOhxKcazbra1oEEGrUesFmj8KpEiAUYItewmitCJx9gGWgfvJSh/D6FOjffGlgtP1tS1Raqk+WddIKkgvvzH/muStsvwJJ2DM2n/KFvQqxVON1K5RW9tYHIIPyQPd27ONA48UpZbYzfy2ode3IXstIyWKdQYh/varxaXb+m+wkhFmCL5jV2Dm2EuVVfhep4cdfzHakEQSBS3RYqlA5ZhcUok/B8B1iPVs1tWoGleTF4Ebj6qm1sOfEyvOIAHJg8GbQWYr1XGOjej1TJ85IqrN3JgwRaBrdXrlZXt4uXOlfnDZiDBpih/ZA49Sos1REuPseYBH5g2mOodjShViY8DViF5fWaQFbew/fvie+qtEev2zcNsDQPnqF7Yi1VXxFeRWY0xIpdqRQzoKYyYgeEV3t7WdMQq64O+LwBG+Sa1vdslG0kG2AZaB/0PZg51ANTN7Rdc8GAWpGgMNT1PDNz0+azOm/3FkK5cdIabn4Vso1O2gysDG4nvFJiMMR6E2tZeHnSEfM7QAXWlirhFfOu9kOIVS8HyiugAfgXbYS7yWb1wYDVV3NCj/gkMAwRTIeswkJ4PnOMR+9PN6nA0jx4hj7hWTng3fdtE17pkRDL0uDHWPtm7Dabo9BL5eaE8Mo7Qqx6eSUrDANQJHNH54qbkGoVluZ2zz0vJNULdC3TY+6Vml6gh//mz9vcyzwqSmul5QDLa9/1Q3JRa6H6asXAdhtkfwu1ROy2XkWqwtKYE8Nsmg0QXgXzksqcWnnPPCzABM3jbnLjCwy0D/oeZxHiIfEFs4j0SHAYImzqJBAQcV2h6MkAS4ZJa81cCV19ZaXapu/5CQf2ICHWhZH3kMqBmpILV8KrcFxAbG31WYTDZw3o01yJ+JXCAjn7ymb1wdZyGGJky8pY50QtXR+eDQKsSngQIHTmXjsjz1Vgac6rCXaik9lXFm4MP4SsMsNuZuOG2z+uDLx9saqwYAjhVTSnci5A/l42uwtudABF0mkQavn9TaTWRqi5vZeeO0NCnGvPaR00I8T51fff6Xtf4f5M0c/P/Gqtg+dt4JY6C5UtbkA9FTZ2uX3/zkCIcM5BsnZGrDYYzadmd3FDFWwtnLuqO2ZNAqrcw+lPShvQU64C21YWqw/KQO5Xvv4+MZfKHxjg2jhby+GV58/ZzcztGF5dkhbCNa4Pz85j5CxWK7BCzr6ysPLgKuVlfetAbnIsfEahy941ZgcQFjxCZvNpXrTW0YSh7rVwQLsJoE7zZvRlKm2Eze5C8/rT9wziEMddCgDsCVFl5/N74Pveg+ICRY8GWNK6pFV9EvIEZ+EClhUHEzAbN1y488HAloY8UcdePGBOyfd6csH63uK2Ze6IGUm10SesBPTIta/mnNFUHh5rbqfvezDfwYa7juScbcz14dldgO/2qa9h7gHuPQ5chZjnvxMbeqoCSytZDNY+KKGcdmvORwlGkABp89Sc2eB0Qt10yQkn5utj319DPl8uyPS8UX7ijTiowgL0aZ7rUpl7qHk+8taaJzf4voshqL6yK0Rbp8/vgu/5xlw3KrEYYIU8sWmfuOYceJOkvd+EWI2jKubFJDML1pswtF3diOqcWqAKC1AkD3HnSltgvo1QHqZoXQ/MPc+E9H2DT/WVYdeHZzfGQyLfbYSnMuMNkT0VYPkeuLepIO2DcsF6GmSLN9ejdTA9cjLXbiUMWTUwkrlsoV3JyQ0Vsjqa1vF2G+6G41K+C6/dz2zc+OnhT1EU/5X//Tf5dy8j7V/7OiBgrYUDnpoC6jRDCOvf/yyqr4Tv+y6KAOzzvQ+98dVGGGgGL4GqgrUBluLS/SFXH9Q+YV3SOpi0geITQ+eo2V0EWfFC+sJjXBTQuvOAPAm2fEHm9vnfi6L4dTZuHM/GDTe/79wdyx47nrmQXv73ify77v/jLj5+lb9LuyX3KaeK5z/Ew7EI0EUb4eOymH8VYD7QSnkRAGxAVg30fb/ka18KcR/+qrUcck0R2WMVWFoX8DkPb2fnTphUzmkHDcH2IVmO2HfZb9UHqq/WGhhtHbyQCisXWg18tBS4v0P+rhMJszQH+T6FJ7zfu5JKut+ksu6/1aq7SsXd64Qq7l6GeiAA4HnysDrkNcdTzLYRKrcPXnouIvAdYI1YBCgZvgNqL7mEzP0NUYzwBwPd4/r5kd+mdWEXqn3wWHl4+4eAlWWIxC0r3OwueposYzUAACAASURBVIrtXqEPjh15OuH7u3J5fXhGKPCAVPq8MbVR324oeqGPVxKI9ZrdxbkERtrt3VWv3GdT84pZF0KNXBXdc/+ihPvle/XPeyYBUU9+LIa0vR0fCrj/zy7tDAOl65DfA7RN1PlhxGjHp/g9pePcRYCbSV/nh5Hy9ZTFlvGcVh/0HmB5/vsQzsjzqto+9yW3n7/z+PeVRi7Euj48o9sqgscCLI0KrJXnwYFVmtVPK+aqZMXdbH9WekEH7uncJjeVu3BPtlrLYdtziHWZ0Ko/sVm6GFtJcBW1PF+CMhdkDeQ4aWUWmPts6jiY073snvsIMOV83peQsi8/loKszi7XBrtepzS7C63KgRvGF/gj342tvx+Krcl3hj//iWIVco8A6zvuHszbNUlrOTzx/LneUsWfDlfp1FoObz3eSxy4fcrTPjAKFGC5/f1zazl8y0ID4f3QQijVShonk5AnWNWBiAxuz4dcCGqVvReh92Upz25L8LSvj9eHZx1Kvn8klXxHRjbHfdbHscOrKmkvbEu1iAVH8hnVxa3MOfNefScz0c4lEPRxXPEl2FxBAM+Ta2Ot8465NkLl9kHfn4PvwJZAID1W2whvAs9i/dRaDkceB89jjXUzsLQu6IIEWHKC0rpRpPoqT5rtcMHDWBc4ueCpKIq3O/aKu4Dv9fXhGXPfHmelpfJ3GbJuImR0M7JkPpaFGUp1CbA+urlkASug70mQ1TEUUhasRgio07xGtvb9z2n1Qd+vheHt6bEcioY+7rh28RvmYoWTfYBF9RV8U67COpCndMG5Etjrw7NjCbKeq5xYlYO/rw/P2vSAP85Q9dVbCYxMkSDl2MBqha9qsCKh2weiBs2yz72N+TufwIqTgCI53mut8GztIYXW/co8wAMMn+MAbmX4NhIin5nP6zhv52tp8Qt93HHX+X+2lsOpjGeBR+sCrNzmX2meoKi+ypdmBU3U76gEWa4V8Cepjnn94OeX68OzF9eHZz2Cq41YqL5663PehW8S/LcNhFg5V2Gp7QPyey2EWFZmrgF1pnWtbGY1UuX2Qa/vv8y/8onqq3T5/OwOPO9bsa7FX8lsrCkVWf5YqcAK1T74QnH1wQuqr/IlVVhaTw3VDoCud9yFVA9+eDK2ISPVV6bDq5KREOtUziO5Ud8H5PdfaL+vNaiyA6zTDCisPKTIafVB38dUAqx0+b6/95ZRRKrCqnolFVluwH2fGVn7+S7Akgt1jScAoaqvNC9Mqb7Kn9ZnfGRt+Cg2pn2x/HsK4VVJQqye8kys3KqwPhraB/qKDwJKBFiAIlk4QmuBBysVEVrbcel74Q7PhRArVh9MV4CuDN/3PhrXd+4h9h9FUfyvtRxOWsthjzBrew8rsJh/5cdt6IG4MEHzJpCbrsRIq4Jmy9KlxZlXz5FjqWaIlFOAdRt75tVTJKDU3h5WIgT0aV1Pqa9Gmtnqg4XnYypjKdLnc2aw13sfCdg0K8HfuFULK2GWq8yiQGEDVgKs3CqwWO61BuTmS+vAR4CVHs0b9XnKQcxs3HAX2R+Vfr2ZOSkemFsZVD5brUUxCgIsQJ8cB7QqbbXPjVoP21eBqnF9jm6hGCB9PkPIEOdrC5XghYRZrjLrL2kzHLiZWVRnrfcwwNJ4k+YhZkVJO6TWrBkCrPrQ6s0nwEqPZqtCL4OZfOesVrWXC5ndZ5FmZaCFFUEB6F07a7cRav1+79evAQa4U4GVPp8hpPdKxevDs6/yHdQcVfGQuy5552ZmSXXWTSXQqn2FVrEmwNK4Kc6t+uqS4e31ofjUkDlYCVFuEbg0HFxsTLndLIfA2MLql2vJcVTtCSiD3AETatdGmNPqg8J3IQQVWOnz+hm2lkPv52uZs2auQr3iZSXQKiu0XMvhuXs/6lilZaECK9TBSastgNUy6kfrM6f1JR1qLQLGT8pbUWw3e5l4YBxiUK9vmudOSvQBZTLvUGvVWa0qW61rg3mgWb0+w4W5VMcgYQFWKg9yvpZVCd+G+LsDOJKWw/dFUXyWKq1qqJV9pdbDAMtn3/KmcqvAoty1fgiw8Byti9RBAsHFtrQqiVKu0kmhrV0zwOJYCthQtzZCtWsDpd+7jdyuXerM54PHYOfrxEKsh6qhVlmp9bW1HE4roVY2D+v+CbBkZpSGUAcojQvS2wxvFvE8rdCStpcEZNgioEraITWe0ltZbn1bK6lcMy2HNlcAe6tNG2GGqw8Wnq9LOSfkI5lKusRDrIcOZPXz95V5WneVFQ+TfXhXrcBSeREhSlil1UPjpMDBtoZkNo9GWxNVA2nQChovMp7HpxHMpRoYp3Re0lqNkGMpYIDy6s6x2wi1Hoqk0FJepBR64Fk+7/WDX4tJiPXa2GB3X44qKx5+kSqt5AKthy2EsYUa2qrV90mAVV8an/2BYuUkNqcVfGRXfVWhUVF0kOgcrJSG4GptK8dRwA6titHYgVI2qw9W+LwBZoB7PpILI68Pz6ayP2vN5Yvl4JFAq2d5jtbPlX9Wuclqdhch5pkw/yoCuZk7ppXtntaXfNDsLlJvW72bjRspzOjZmgSMGrMFbwMNaDXBPaVvdheXctKNqZ3IPKmqlM5LPHEHas61PDe7i7lUCsR030YY49yp2D64Cny9pdUSCdt8fqeiPXCSAfQnreVwIKsA1kEZaN1fX7eWw1u57p3Kao0m/Ky8EUfSl5mD24zbdf4hN+R9eXKkcWOO753m8H64Zexn44bWKkAhaZXj3rj3VOl3x6IR3KbYapZSwD3N6JoAwO4mSjeMvUgr9+ZYfeWVVMAAD0W/97w+PHPtdRMJcmIH69peSnWWC7PmcgwZBFhdcivVAIsS+v1kX+oq1XJ9nrAggNNmd3EzGzdya3vTCpFOcwk3jUkuwGJhkY0wAwuwRavioZN5gBXsGiunFc7gXfIFHhKoHrsV/Wp8L3wkx+V3lcqs0fXhWfTPV32Ie0ayvUlwJdUuXJAn44RXCCXHix+Oq3nh88wT5zXAEAneNWbPHIWuXlZsH5wHbo/k/Ii1LLWe7ev68Oxc9nWtxSasKCuz3MqGo9gD4LWHuOcky1JXWVZ4SrsgsJMUh37jcSycAABxaFVkhx5nkF31VQA5rv6GTLj2uevDM3ec+IUg696pDICftpbDKMc3Aix/sqvAqoRXPJ1GDDkGAwS/+eEpMwCEN1EKMkLfgDH/6nmsQAjz1gRZdQ9eXxVF8WdrObxzqxiG/EW0EHqS25wRqTIYEV4hoqyOQRIAIz9U1QFAYLIwkkbociBtft5Je6LGdfUV8xCBMCpBlrs+/N2169b8rXazsj61lsOb1nIYpCW7GmARVOwuxx21T/UIsBdazfJEgAUAcYyU3udQVVJa1Vda7yNQG26Y+fXhmVuhz10n/kpV1n2O8FlaC71eO9NC6Edu1VfHLGUO7I2gI08EkwAQwWzcmCo9JM4pwFol1j4IJM8NrndVWdeHZ+6a8beah1mutfBGVnD0ggAL68RYQhjIHQFWnmgNBYB4NKqHvLcRyliBI59/54Ym0o4JQMH14dlkTZhVtzZD1+n33lc1FgGWH7mtQKhV4gwAAACUcmkjDL264WNSbB98ZWAbAO8qYVbZZuhmZl3W6J0uq7H2Or4SYOE7ik+IgNwuWGg1yxOfKwBEIsPHNW7wfAdYGg+H59KGCcAYaTN0M7M614dnPxVF8booig9yvMu53fBAVivcuaWQAAsP0R4D+MF3KU8sbgEAcSW9GqHiw+Fo1VfXh2cEZVgr1Ep0uXHfoevDs3MJtF5Ihdbboig+FkVxm+FLdi2FOx2jfva/LUgcc3sAAABgwmzcGDW7i4HCiukdT+EZ7YNbai2HL9yqbkltNGKozSB0V6Hl2u2q/52EgcfykPwkg+6V09Zy6F7rVsdIAiwAAAAAlrkg6TTy9vlq+9NoH7yS9stUnWQ4Y7iufI5euNng38nWukpHGYruftryvTlOrFtg6xCLAAsAAACAZQOFAOu+jXA2buxchVWH9sGKOXN0sQYjNQK6PjxzQfXdw8BXqrXalWoty9/NrUIsZmABAAAAMGs2btwoLT2/b/WURvvgSmlumM+KL+Ym5cNnBVbKVYVRPZip5aqyfpGZWhdKx9LnuBBro+MlFVh4iAMDAAAArHFVWH9E3qZ9AyyN9sHJbNxIfX4UK/7mw2cFFvepO5JKrVFZnSmth205Rr0xspmfWsvhjcz/ehQVWHio1r3FgEfMbgAAwB+NtridVyOsWftg4fm6h7azfPhcIIzB/p64QOv68GwkFVo/FUXxm1RnaQ/Kn7hFHJ76Fwiw8B3FEm3gqvbvAAAAWEuqii4V3p1d2wA12gfns3FD6wGaz3CBACsDEkT4DHEptAjk+vBs4mZQXR+evZAwS+NYW8j+0n/qXyDA8iO3Pm2NvnkAAADgKRrVRW+a3cUuLW0a7YNa1VeF53Dh4LkqDCTBdxBJC2EEEmZ1ZG7WB4WqrPfS4rgWARbWGfCuAHvjKREAAB7JioAaLS5bhVE1bB8sAoQLVGGlz+tnKHOcEIm0GZ5LVdbbyF1ajx7LCLD88Nnbq242btxJ2gpgd/TpAwDgn0ZIs201lUb74JVcw6sIEC6wEmH6fH6GjBpRJPOyjiNWZL1qLYdr959qgMXco91pPGEJzVVh3Wb4uoBYeEqUJy6gAEBXCm2EdWsfLPk8RxJgpc/nZ8h1tQGuIkuKd2LMyFo7C6saYLFT7KHZXeRWhfVVnh5pr0SA+sjqGKT5FBQAgFzJgkMaD1k3CqWU2gdXRmbY+hyf8Mrj34XIWsuh+x4cePytjOYw4vrw7KvMyPotcFbwZt0sLFoI/ckqwCr+vUBoE2IhkhwDH6p1AADwT2Ne66ZVVRrtgxN5+KzNa8jwWAsRkuD7syPAMsYNe5c5ZyEfKPxwPP05lTcoAe5LqrVsbTAuxGp2F20pS36Z2+sDArtTeoLIDLtwuIBCSljFC7lyN06fIr+2+zbCDYKiurYPFgHOkZ0c769qwmuAdX14xn5gkJt9J0HzNFBW4AKs8+p/UQ2wppRq7iXblTKkEuuk2V2cSy+qz3JQoJTj0HP33TlV+L0T+d4CqLcTI21FgFcuRGp2FxcK59jOU2GRUvvgfDZumLi5vz48u2kthyuP9wqdx+bgwK7WcugenrzxuIF0NBjmWgoDhlhHrh3VHVvK/6LaQjhg59hL9ku9zsaNcmjb7wx4RwA5Bi5ar4mSe8AWZuJBQ+7Xphrh7HPVVRrtg1aqr0o+w7QjmaWEtPiuQqT6yjgXYsnnHmL00Hf70z8VWFIO2252F/0MSs5PPKe+mzjasKw4afL6XNg5kMH1x9wsZ+l93d8AH9wT0WZ3ofGr+0rzQQCspxVgZTefE1vJuoV0Nm5Mmt3FPHLF03NthHVuHyxNPd+H9ajCSg4BVg1JO6H7vv7p+dV/lzX8MANrNm4kf9MjM5tiB1iFvLm1KdWXVdbuOKjkRZaJ1giwcq1QuFJoz3aBettKSwEANQRYNmhV49ahcmWkcM2yto1QqX3wyuCqx76vPWgjTEiA9kHmXyXEDXZvLYeXnveB7+6jcl2FkLYdYHcqF7wGL8B80Qq1NdoYAKynVZ3NbFMbtD7/A3kolTON6qPHqktoH5Q5WG4ul8e/8ojVCJPiu/rqMvP3K0feA+fqMSDLAEvKekP0Xz5Ho2wY8E3jib3G9zUWradGp9LmC0Cf2ow/qQqBLs3xElnf+MvDr9gzfN88EgzGvg9YGe788L1dPJRLh+/wguqrxLhWwgDB4z/3NLlWYBVKF4tH3DAiAxr7cLYr5slqgD6fRG7j3N9fBSBRVC4oU14Vtg6fv3oVllL74MTw7F3focOptKbBMKmS8b0KHSvppsn351aLAEsrraUKC6nTuNjNfYUurZPvKdUXgD7leXRULtigVWlch+vSicL7+/B7RftghZuDE+AzYQ6Wfb6/B7dSzYP0+L73ybuFUGg97eJCEanTqMDK/eSkeZHJaoSADVoBxkuqw03Qui49ksWNsiVVSLEfFL168L2KHRTOE1iohTbCGmkth+77cOr5FZsNafG068Ozr6Hau39YhTAjWgf1+wvFjAdSI2My0yF2CXyRcwthIe0jCkt9l9xFdj/lFWaliuzEeLsE8JwbxaHqfaoX1Gl//rnPkRkFuHl+jgutBkrtgync2Pv+TNww99714Rmhhk0hxlZsHYK2lsMTzw9vb64Pzzh/7sbnee+fvyfbCiy5yblV+vW0ESJVWu1mdQglNAOk88RbCd3F6idXqdfsLgZUkyBRqm2EfG/UaT7YfFODKqypwrzJsiJI47rffIhzfXgW4jNhtqdBgaqvLndsH3whYYevH0Zx7C7IeS/nFsJCsaqDlBapUjlIJ1AG74PmxeaB+/0pLqfe7C7OKwNB3et4VxTFX83uYpL7DRmyo1lpekA7sTrtSuM6fP6xX2PZnhs7wLpKqNPD97XPfRWW578T+zNRfSV8fzdYPGB3Qc57uQdYWoOTs583gGxp7LdaK/RFJVWhF4qb8DK1lVzkOPr+kf/5TVEUn5vdhWvP5GIWKdAOMN7wXdFj4EHNS3kgkDONc1w/wKprz0mphS7Etg5YkdCOQNVXq11bRQMMfY/9/cYzcg+wWPUH2I5GBVad5sVpPwF387CSuPCVlsdNbkbchcWnZnfx1d2c0SYFq6RiQjuw/8TKpKqCDLTdwvucQ0z5jl1G/rXvIv++VUoPoyRM8P2ZHNDtYkqQkDLh9wOBeQ2wXBreWg7bD37ULpSU52CdciOFlMj+qjFkvA7tg/fcMHcDNzCn1kMsucGeykXqpg6kWsu1F46ogoVRFo53Uyqx1Fj4/F2ImfPNf1KVxjtIcTGTEGHEe6n8gaLWctgJtDiFqetUzTwD/yq/83sHWO4DbS2HrpTTJez/cy0dD36+tJbDv1vL4cT1LCuUfGp+AbhAREq0bvizXoFwDQstHKfSemeuBH/H8OqhU9oLYZSFAONAQoxBinPxEmclXPlD5ghm9/nPxo2RVCnlKrkV+AINcy9SfC9yIvf0IcLJCw9tgL4LWDhXGlDuFzsHWC4Bay2H7oD0Rcpnn6vceFOuItVaDmM++dG8WOhzcYiEEGBFIHNQtKuwCmm9u7HUTiRh077hVdXD9kKOx9BmqTrknazsybVKJFKFayVceSOff47HxlyDjXnCi96EeHj3SiqAoOM8UOeGj1DMd5UiVf2G7BRgSQD1144lg+7G5I/WcngTo/RTeeYEPdpIicbBeZXQSjo+WTkuuAuPL9qDfd3Nk6sGkIccvsKrqrK98H/SXkgpOFQojzZY5/6aTIIM993oMf4gOEshZvXYOMno8881wEr2dclA7iBVWAx0j8+NCwo0/+3q+vDMx4Nt3/cWXDca8vO2m9JaDkeeVhq4f/rvvgCedtSnTBSGLJbck81Bgv3qqBHF+Vd1ax+8557CN7uLiwCrtuyqHOzbi/10V37vIFBwtc6ptFC6KriRtJsAMY0kNLLkoPxuyPdyJcfnr48cp+/47uxsYujYX/VGfpL//OUce5vh6mGpf+fO5UGVTwfynaJCJhIJDEPti74eqPoOsNi/dhMk+NuqAstjeFVyB51phMFomisZHBiZeQM8RevAXJsB7mv0jc3pOJK5UW7Ac/CSfHnSfxew6uo5r6S9MNcWGtiVwk3ogXxH3kiFzsMfZsvtaDZuTBKY0ZTD559bwHqVesV6wCqsV5HH09TdKNBD7yuZl+aD7/uLAwa57yTItfXGAZYbwB7oidFB6PJPOeBrluy/oyQfxmnNEKhtgCVVmRbDbXfT8qcEOwOf7Xbu75I2pa8SXGlU/T10RHshYpLv/gVveq1RvRZebu9xLq8n1HXPHwQM4UlQ+CbQL/IZQoYIe3lwsz2fBRL/zA/eKMCSWVUhq5heRriR0z7wc7ECy0KdjJ5TyxbC0mzcGBgZ6L7OkbRef5Ewq5yPs9HJSOZatWVA9ERCqy/yIESj4moTbtumPHBABFwT1JtmZ0AtSFB8mclrXRmbnbazgFVYhXT1UE0diASEodrfL3yOFJLV6nxXurJgwPaChMqbzsA6j3DD8a61HA48LJv5GO2ZE69cW46UjgNmxGgXe8Qts+Hu9STIsxrqFBJmVefjFHJhsO5i40Xic0cGNV1YABG5WXPN7mJupAoRkbljTLO7uFR8eFQXo0ze40lm10vuuudzgL+3HE3j5itzfemRFLOE6ppYBSpkmXr+/h+5VS+vD8+4l9+ABJ4+723+ued4tgJLkuxYwyaDVWEZKdkfMWcFBtE+qEjCkhTn5JUzUh7+pBxeuSXKmVmIWNjX6o0qrMDkobHWSuQ+ZVWxKXOOQlXHveS75ZdkAZOAD1pDFbCEuM9g1trmfM9X/mcf2aQCK2a/Z+gbad9D6Ld1INtACWKiJIA8eeRL6Q6UNwk+JSPAUuZaCaU1j6fxuphvgGjcKm5uAQGqsOpJqvCu5AEAwtFcidyHeezVgSPpy7V0iFDktLUcuqCMc/qeJLyaBnw4Ob8+PAv1MCfE9+aVVPhxD/M832Hf5hVYkW9u3YT/YKuhyQlAc5i780axZQs7klk+7iLof1L2vG5Vns8yCHqSymcs26nVusbB/3u9TJ4Up+pjpjcJsI2nufVGFV54qVfjZDkvTypuQn42p7J6PvYTMrwqQj44lJlaIa6rOW4/Q/Icrw/nqqHhJgFW7BUdQi/nb+FENmJIcBpk1bSphFObVse8kVXcbjYdeK1IK2i7Yv7V9+T96CSwvHqO3Dw2ggREJy1OVhdyQGASmrMiZUAGViLfV7YhjFTehPxsCLF25Cqv5L0LGV5dRKhkCjGvylVhUYzyNN/B5HfHiU0CLMuDhbfmSvYNVDkc5LKaSM6ktePLHuX97qD/Wf4ec6QdkvZBQ2bjxg0VGdGtaOuGMr7z9dbnwUVwqVZhXdVgUZHQbX6EWFuqtA2GHLuzinTuC/XZD1jxcj0Z3u573/nuvvHJAEs2ILYYFSsWTmQvm90FQwaNanYXI2kL9OG9/H3WaLYPEuA+QkL2301uXJ56rDoITRJcf+BDqCepvqUlJaxUrzmyD16kzSv08Y8Qa0MRZl6VOjFWigzYRnjEYgGPCvG+bB5gyXLoORoZedr1rtldMGDQGAmbfCfHpwZDLK19by43bHiEG+pOW0kUv0sLF6BKVr9Muc0Je5BjfqhV2WrPyErk21rV5WFfhFbCQkKsKVUzj5PClRjh1cfIQ9BD3X+5fYr7+IrWctgPsDDJ6vrw7Ltj4ZMBltKE/eA3tnIis5KafnJzlgxsB76FV72AJbOnVoa7yww2rZWPaB/cwGzc6BFiBXUhN42AFT1ayWqNzz+s1CpwJjWbFRpjBqi77p0qdRiZJjOdYoRXt9eHZ7Hb5kNe631if/pG3ocQ1cQ/BPmbzMCKLdbBemDoQmFKiKVPwqtPgTdkJLOntGnOXKHiZUOEWMFcyHsLmMEMvHqTsML6wi/JkoH5Ka30W6trJVmVMMZ5+aWEWMy+FK3l0IUOf0YYK7LS6P6QVsWQ19K1D0WlsnEUaB/aKcCKvTpOlOoMuVCwcqF4ICEWZa1KJEAMHV4V8llb2O+0bt5XtGxthxDLO8IrmCUz8JiHVVMSYr6t+/sQUCpVWPM6XitJm1CM45+7Fv+ztRzWehB3azk8dm2VHmf+PqcnM6k0hJwzeFDnECvw3LT5w/bBYsMAK+YBdBWzbdHIioQlQiwlEl7FbGtTDbCk0ozh7QmRwIWb2v0RXsE8mYdFaF1Tcm1KiBVGKgFWba+VZB5WrHlw79zomtZyWLvKR5lVdBNxnMiHdUFELFLhF/K8WssQS8KrScDW07XHbGsBlsaObalc/yUhVlyV8CpmoHOgPAuL9sEEyU0tNzW7I7xCMqi8rDcJsfj8PZMVZ2N3luyi7vMZexEXtXCryX2uSzVWperqj4j3PhcSTGoLvQ1liFWLa81K5VWoEHT12LHw2QArQmJZFf2ALSW6lk5mhFiRKIVXJZUAq9ldtCMMaHwM7YN7kpua1wz63dpbwiukhhCr3uTz56GFf9arsG4laKstmVkUY6h7lavGuss1fHBhg8y6+ivyIk63VopFJNP4GPjXHMhg91HOgahULd4FvqccyLHgB5sOcY+Rml4o9sVaO1i5neGOwe7hSBvdF8VWumOl36v5BITwygMZRHvCkvsbcRe/ryX4A5IjIcbvfHL1RDuhf/KeWn4IVPfqq3sSNrQjf1Zl+JBVW6GEcncRZ12V3HVq+7EQQsl5pH3qNMf21EoQ+jnwPfSj1VfFpgGWHERCzl9Zaaaz8qTD2nyZA1YnDKPZXfQjDWx/SsynH/ea3cWxxu+tIMDyxB2zZuPGSYQnSSlzlbXHEvgByZqNG+4i7jcqL+tJApdf+fy9snw9wrWSkMKG2CFWIYUErq0w6dUKXXDVWg7v5J4n9gP7lcHwqqzui1W4UranumosrcIFbyQIvYkUhD5afVVsUYFVDtULUcpuZQcfGFxe1x1svki1EDxodhcj6fuuI83qq1quqBPabNzoS0thSkuDx/BhNm60ZbVZIHly/DxJZH4PPJPVCY8jDrfOndUqpwvOW9+TEEuryOGVrFZ4J2GQ+ZYwmXF13loOv0pwdaSwGSbDq5IMk495LC2rsc5TDLJciCtz02LtT/PnZqZtHGAV3z5w3/MYVspLav5DThhWg6JPErxgR26mWLO7uJGDSO1I9ZXmaye8CqTSUkg11reb+19l4D2QFam8bEtLIdU4NeOuU2fjRodqvP1JIGjxwQ/XSmtcH55pt9Ieyc37nVTTmGsLk5BhIjOu3iuOSCnDK/V7+2f0FNpT3efyl+xDpjuspFWwLxV8f0bu4Hk2j9kqwCr+DbF83CjNZQc3c7CWG0GrN4GnLoCRIAJbkMHloQfNWad9Q89Mh4DkxqYvbSZ1rNBYyaD2ttyYANmSlsITbkzmSgAAFABJREFUBrzXk1TjHfPQYm/WrkuoVH+ChFja4e2BPAz+LFVZA60WQwkYOhKGfJWQ4Y3GtlSkEl5VFwrQ4PahLzJrrW+lKkv2qZ4Eof+TjqXYFXwfrw/Pnh398dPff/+9098u6fNgx1DAnXTPLZYWyup/N0oll5u4r1rjJLeZZncxkJVFrLmSJ+kx3oNjeSKjJdprxT+feU9CS6vHMV/KIY8Dy20XEqJ/1vjds3HjJ43fuwvep+3Je3auMN9w7+N6s7vY7QJ0T6l+1uvI+f1cocI6+fO6gWujhz7Kgyg8QSpXtFYQf8qVbJf7ufF9jyvti215eNFWnmm7jsWB7c9yAZKR0TK3lf1nGuN9lOCs3J80V6kvbbwP7RxglSR57m2Q+s5l6dqRDIU3S/MieguXEmTRK7+GDL8fGa66inah0uwupsonuresAqcj4yArieCqRDCzGd6n3VWCjE6kGzsCLEPk8+/L9XgSn78Fze5iYqBqpfSLLCqFZxgOsarm0v1RVpNUq0p+CLgkoCrbysp/Lv88Mf5akwyvSq6KzeCImbkU1JQ/7r292zZDkZDqOIF9yl3Xn2z6+vYOsKqkKqt8o0rTXd5wbc3u4lxhudFt3a/eSDjwL6mgOzdadVX1W4wqOgNh7Go2bpgfepm7jIKs8kFIEsFViWBmM7xP+5NzYEd+Qt6YE2AZ1ewuNn2wvI9cAqyOtF5pu5WVhbEhCXymNR8PYoFrZe+nGl6VpG3OSpi9qXUjQ6yHnY95vUnrYOlnn795m19snRsCLBfT1ko0qw5kwHtPgqxaz35J6CZ9FbEFlNlXKJdhH8kxrZfgYgau4nRE6zTwNAl2y+972XLSkYtabvRqQI6T98dKCWistIeY496rZnexMnDDx7XSllxgIoUTowSDh1x8eG61uIT0EgxELWcU23i7bYbkNcDKUEfKP60nmW4H/tLsLlwKfl63EmTFGSC7inKhIoGe9ntCdaAhslDFtNld9CNVaezjUm7CJrRKA9uT7001zHhRmXdRbSfY9oK9bG2AcdUwq/j3eulEOiXKip9trxNWmX3+IwNV+zyc2UE5iLu1HKbQNZOT+3nMlhZi21clEKWqL663skDDVry2EOYokXlYD9UiyEowuCrkwv8k9A25kcUILmbjxrNLoUJXpeWoHXF+zjrfDbAktALik/mRD9u+v9a9wrsuZJbWDytiycOPLMk+/0XxtXGt5IGED5NE26dScivhVZbnBGlNpaovjp3Cq4IAazNSrWBhhYJtZRlkJRpclV7HuBA0MsPtV2560iM3MO3KkMcQ37NbqW69KVfsIbACAGhodhc3ilUXUWai1oGED5OMWqus+ejuv1Kfd7UJo4Pdc7JzeFVYC7AqvfpleXNZPXIl0/fLJ/PRb4qb3UXKO3Ly82OkSqQnq+ykOog6ymp8RpaGzmLAK76ptB6tWyVnnTv5Kf2zggqrLAEALGl2F3dK15bz2bjxQ8Ub9tNaDvvyoJtqLD9cy2Anp1nXm5D9KMUCFstWsmLlXlmOeoAlN0Z9+dn0QHMrq1BFna/T7C6miaf6c3kyMUjlJlJCzU4GKXi0EnEj+2mUSjMAAIBdKY8K+TgbN/p8eP61lsNjaQWjGms/tam6WofWVK9uJQjdO4NQDbAknBjtsVO4yqxerDBGwrZchrvdVgYkm2rzqoRWmvN4fLqcjRudGL/ISLsry0EDAADzlDssfqEqOazWctiTxZMIILYzl1lXtX8YTWuqFx+vD8+8hfVqAZbHE8ZKQqwo7XESYqWwMuE2VvLFLGfRRA205OlX+ZPbwcEFhe0Y832kdfDGwL4ZpVUSAABgV3JN/z+lN5CHfZFIAHFuYLXJFLh7wsH14dl53d+Ih2hN3UmQIFQlwAr0tCPaTbOsWDLNeAdeVYYrl7Ns9h6yXFnd5qQy5yznNDtaeFXYaR1kngMAADCv2V246pxPStvJw77IaCt8llv8q1/XdsFNSBg6YMD7s4IGodEDrGZ3MQiUgK8kLIhSPVSDEOsxtzKMuVgzqLmquhT3ccKD13cVO7yyMmiQCzIAAGCe8uqD/2X1XR0y1yjV1cxDuJA5V7Szboh96EnB96eoAVaEQYmuTO0kYmhQ1xALT4sdXllpHaQcHgAAmCfX8F+UtjPawj54nIQQ7gHwm5q+TQRXe2othx2pyKpbocY60fan/4T+BQ+Ersw4kjQ0Cqn2akv1F1DEDq+EldUxWEkHAACkQDNAijK3F09zc3muD89cAPGL3HzX4X7OFXt8cBWA14dnPcKr/Vwfnk2uD89cIcFvsrhc3azku/NLzP0pWgVW5D7z32INdS+oxMK/oodXze7CBbbvDXwGV7Nxo21gOwAAAJ7U7C6+Kl23MyvUKJlv1JEHsjmsOF916QpJXOBiZ5Py01oOT2T/yWUl/cfcSmHSSGNmWswAK2af+UpaCaOlyoRYtacRXoVuyd3G69m4UfuldgEAgG3Kw9s/zsYNKtaNk4HvZRCRantYGTJMqLSKqxKGdjJqUZ1L9agLraLMHH9MlABLZvT8FfwXfS/6PB5ZjneaYWqPp7mnGr3I4dULGaBvITBllgMAAEiC8qrNv8R8wI79SVVNW8II60O7L+VelNDKiAdhVjuxYpcrCa2m2qFVVawAS+tJR/QbawkWJqxKUBsq4Y3yyjkPcTEGAADMUx7ezmI3iZMwoi0/J8r3eytZxGkqAQOdEAmoBKJtY4HWSfalG+v7U6wAS3NOj8qy/s3uwv3O09i/F1H9Phs3BrF/qbF968Ns3Ii2cAIAAMCulK+hVO5JEJYEEu7nWAKJ4wBth64d8GslYLizVBGD3Um7anXfOZb9KVSwVe5LN9V9SmOW1a5iBVjaN9y/yoqBUSn32COclbQMRh+EaGyfmsusuWQOeAAAoJ6URppU/ZdrpvqQaq2y4q4MJjZxJz9FasEC/KqEW4XsS26f2lQZUt3LqUIvVoCl2WteaAx1LzHcPTu3El5pBKKWhrYXsVf7BAAA2JXy/QjzQgHAg/9EehO1k2MXHk1kPlVUEnQcyxA0pO1CVhrUCK9OZLaaFVeEVwAAIAXyEFDzYTrXTADgQawAy0KP7kutk4crF56NG+7E+UHj92NvK5lbEHWlwZIEryNjVXw8RQQAAOZVrqO0zHnoBwB+xAqwrKxQ9krmcamQYde/yuwgpOFK2k9V9hu56JoaWnGwkMHtrDoIAABSMAowVHsbhFcA4EmsAMvS0LBT5RDrRoawfdTaBmxkJasMtpXDmomx8OqWVQcBAEAKmt2FWy36jfKmRl+xGgByFSXAkgDAUtWRC7HUbsKlpbBfFMVrqrFMKquuVC84JGjVnNewDq2DAADAvGZ34a613ylv5y1V6wDgT6wKrMLg04f3ze5C9WZ8Nm5MZ+PGMbOxzChnXWlXXZXh1amtt+e+ddDCPDsAAIBHyXXUHwbeIaqvAMCjn/7+++8o76fM8rkzNoi6kMBCc7DjvWZ3cSw9+tYqburCtXSeawxpf8hoeOWeIJ4Y2A4AAIC1ZNXmkZHxC+7B6LGFa0sAyEW0AKv4dlLpFEXxp8H3zkSIVfy7zO/A2NyjnLl2wb6VyiKj4ZXzK9VXAADAInkQfG7sGurCrWBtYDsAIBtRA6zi2wlmYmCY4jpmQqzi2/vUkxOx5qopObuSiiszCwwYDq8+MLgdAABYIqFVR+ZzWnzwy8M/APBMI8Cy2kpYWLxRJ8jyzlxwVdgOr67cTDAD2wEAADImnRqPtdsdy88LWc37xOi9RInrJwAIIHqAVfzbJvfZ6AdqstyXIGtvVoMrdyE2MTr7bCWrMbJ6DgAACKrZXUwzmgX72to1JwDkQCXAKr6dpFwY897oe2i2Z12eTvUZ9r6xCzfM0+JFhIRXU8Pzzn6bjRsTA9sBAAAyl1GAxcI3ABCIWoBV2D9R3RZF0ba6ckhlWGXHeAm1hrmsQDOyWj1kbJWcdT7Oxo2+vc0CAAA5yijAMjVXFwByoh1gWZ6HVUiI1bM8gFHew478WByOH5OrtppYrxqS8Gpqeb/nySEAAIgpkwCLaygACEg1wCrsz8MqZA5QJ4U+9gRWYwnhUmZITaxWy1XJLLNPdrboB25/P07hvQQAAPnIJMBi9hUABKQeYBXfTliuVekP9Q152u+zcWNgeQOrJMxqZ1iZtSoDK1fFlFLQYnilwSqWfAYAANFlEGCx8iAABGYiwCrsubm3DWj9FKtTpNKt/Enp4mAl7XZTCaySC1eMrzRYxcwGAACgIoMAi4eAABCYmQCr+HbiukW89c38XKxNSKB1IoHWsaH3/UrmormLmJtM3udJAoP2za68CQAA8pd4gMXiNwAQgbUAy1WquMDiyMDmPGUllVhZVatI2PJCgq3jyo/vz8OFgF/ls/4qYdXX3J5aNbsLt0rkewOb8hxK3gEAgKqEAyy3+vUJ80MBIDxTAVaRxgptVZdSjVWLE5Z8Ni8q/1UZcq1ThlOlu9m4cRd9oxXI/LFRIhdhLkxsc9EFAAA0JRxgMbgdACIxF2AVaaxMWDWXEIsTF9y+25HwKoUAdiVPDGsRLAIAALsSDbBoHQSAiEwGWMW3k5ibx/PJwKZs6mNRFOdUstSTtL+OElrxcSWVVwwbBQAA6hIMsG5n48aJge0AgNr4j9UXKvOlfjewKZt659rmpHoMNSJVV3cJhVdOh/AKAABgJ+5BYIe3DgDiMluBVWp2Fy7IOrWxNRu7kCHvVGNlLLFZV1Vvc1uAAAAApC2xCqxfeRAIAPGZrcAqydL+Fza2ZmMucLtrdhf0xGdKVhi8IbwCAAClbeEVwCgw3wFVinRSqxCVnnrM+Q9D9IuOCiK4ijBF0R4BQAATEqkAotrKQBQlEyAVaQdYjmXEmSx4luCmt3FiQRXKS7vXHDBBQAALEsgwOJaCgCUJRVgFemHWAXzsdIic67OE9/nuOACAACmGQ+wuJYCAAOSC7CKPEKslVTzDAiybMokuCq44AIAACkwGmC5a/Y2M68AwIYkA6wijxCrqARZI1oLbcgouCoIrwAAQCoMBlhXRVH0uEYHADuSDbCKfEKskmstPOckqUNmXPUz2p8IrwAAQDKMBVgfZuPGuYHtAABUJB1gFfmFWIUMex+wamEcsqpgP+Hh7OsQXgEAgKQYCbCougIAw5IPsIpvJzwXQPxhYFN8mlfaC5mT5VGzu3ghoVWvKIqjbF7Yt5bUDuEnAABIjXKAdSWdEFxDAYBhWQRYxbeTngsjPhnYlBBce+FkNm5M8ntp8Ui1ldtP3mT48hgyCgAAkqUUYNH5AAAJySbAKr6d+Nou6CmK4sDA5oQwl9c3IqjYjMy26slPrvvFrVReUe4OAACSFDHActdNI3k4zLUTACQkqwCr+DewmGYcVpQIsx5RCa06mbUIrnMl4RVtpgAAIFkBAyx3zXwj9weEVgCQsOwCrOLfGUfuJPXSwObEMC9Pyu7PuoUZ8nm3JbDq1CC8LF3Mxo2ejU0BAADYnYcAy1VWuWvgO/lxf98dgRUA5CPLAKv4N9QYZLZC4aau5KQ9zbGnXz7bk0poVZegsoqVBgEAQJaa3cVxURTHz702ZlcBQL1kG2CVMl2hcFtXUjp9/5Nay6G0BJ5UQqs6BlYlVhoEAAAAANRO9gFWUY/h7rsoQ6278k/tEuvK07a2/HmsuJyyRQxrBwAAAADUUi0CrOLftrMJgcizHs4PKKQdsbR10LWmDLwtfx5XfnIftr6vj7Nxo5/2SwAAAAAAYDe1CbBKze7ivCiK9za2BniWaxnszcaNCW8VAAAAAKCuahdgFbQUIh20DAIAAAAAaq+oa4BV/NtS6FZxe2Ngc4CHPszGjXPeFQAAAAAAahxglWSVwnOqsWDEXKquklopEgAAAACAkP5T93d3Nm4MiqI4kVX5AE0f3b5IeAUAAAAAwPdqX4FVRTUWlMxlUPuUDwAAAAAAgB/VvgKrqlKNdWlnq5C5D1J1RXgFAAAAAMAjqMB6RLO76BRF4QKtI5MbiNS5ltU+7YIAAAAAADyPAOsJslKhayt8b3YjkZqVBFcjPjkAAAAAADZDgLWBZndxXBSFCxxemd9YWOaGtJ/Pxo2vfEoAAAAAAGyOAGsLze6iLUEWbYXYxpUMab/jXQMAAAAAYHsEWDtodhc9Wa2QIAtPuZKKKwa0AwAAAACwBwKsHVXmY7mfgyRfBEKZS3DFnCsAAAAAADwgwNoTQRYqCK4AAAAAAAiAAMsTgqxaI7gCAAAAACAgAizPJMjqSZDFjKy8uRlXI4IrAAAAAADCIsAKSIa9uyDrZbYvsp4ui6IYMJwdAAAAAIA4CLAiaHYXbanKOs3+xeZr5aqtJLi6q/ubAQAAAABATARYETW7i2MJsnq0Fybj1oVWRVFMZuPG17q/GQAAAAAAaCDAUtLsLjpFUXSoyjLJVVtNpNrqpu5vBgAAAAAA2giwlMnQ9w6zsky4lKHsk7q/EQAAAAAAWEKAZYi0GHakxZAwK45LqbaiRRAAAAAAAKMIsIyqhFluAPybur8fHrn2wCmhFQAAAAAA6SDASoC0GbYrgRYD4Lczl8BqSnsgAAAAAADpIcBKULO7OJEgq/w5qPt78sBcqqymElrdmdo6AAAAAACwFQKsDEigVYZaJzWcn3UrYdUNgRUAAAAAAPkhwMpUs7sow6yTzEKtq6Io7iSsupmNG1MD2wQAAAAAAAIiwKoRqdQq52kdV36szdRyFVVfJaT6KtVVd1RWAQAAAABQTwRYuCerHh7Lf2xX3pX2g3foZIeZWysJo0pfK/+5+s83rAoIAAAAAAAeIsACAAAAAACAaf/h4wEAAAAAAIBZRVH8H5L0NikyxB+IAAAAAElFTkSuQmCC';

function buildHTML(validSpaceIds) {
  const spacesListHtml = validSpaceIds
    .map(s => `<option value="${s.id}">${s.name} (${s.id})</option>`)
    .join('\n');

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>entityOS · Space IP Logger</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@300;400;500&family=Sora:wght@300;400;600;700&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    :root {
      --blue:       #2D3FE7;
      --green:      #3EE68F;
      --dark:       #0A0F1E;
      --surface:    #111827;
      --border:     rgba(255,255,255,0.08);
      --muted:      rgba(255,255,255,0.4);
      --radius:     12px;
      --radius-lg:  20px;
    }

    html, body {
      min-height: 100vh;
      background: var(--dark);
      color: #fff;
      font-family: 'Sora', sans-serif;
    }

    body {
      display: grid;
      place-items: center;
      padding: 2rem 1rem;
      background-image:
        radial-gradient(ellipse 60% 50% at 50% -10%, rgba(45,63,231,0.25), transparent),
        radial-gradient(ellipse 40% 30% at 80% 100%, rgba(62,230,143,0.10), transparent);
    }

    /* ── Card ─────────────────────────────────── */
    .card {
      width: 100%;
      max-width: 520px;
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius-lg);
      padding: 2.5rem 2.5rem 2rem;
      box-shadow:
        0 0 0 1px rgba(45,63,231,0.15),
        0 32px 64px rgba(0,0,0,0.6);
      animation: fadeUp 0.55s cubic-bezier(.22,1,.36,1) both;
    }

    @keyframes fadeUp {
      from { opacity: 0; transform: translateY(24px); }
      to   { opacity: 1; transform: translateY(0); }
    }

    /* ── Header ───────────────────────────────── */
    .logo-wrap { margin-bottom: 2rem; }
    .logo-wrap img { height: 40px; width: auto; display: block; }

    .badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      font-family: 'DM Mono', monospace;
      font-size: 0.65rem;
      font-weight: 500;
      letter-spacing: 0.12em;
      text-transform: uppercase;
      color: var(--green);
      background: rgba(62,230,143,0.1);
      border: 1px solid rgba(62,230,143,0.25);
      border-radius: 999px;
      padding: 4px 12px;
      margin-bottom: 1rem;
    }
    .badge::before {
      content: '';
      width: 6px; height: 6px;
      border-radius: 50%;
      background: var(--green);
      box-shadow: 0 0 6px var(--green);
    }

    h1 {
      font-size: 1.5rem;
      font-weight: 700;
      line-height: 1.25;
      margin-bottom: 0.4rem;
      letter-spacing: -0.02em;
    }

    p.sub {
      color: var(--muted);
      font-size: 0.85rem;
      line-height: 1.5;
      margin-bottom: 2rem;
    }

    /* ── Divider ──────────────────────────────── */
    .divider {
      height: 1px;
      background: var(--border);
      margin-bottom: 1.75rem;
    }

    /* ── Form ─────────────────────────────────── */
    .field { margin-bottom: 1.25rem; }

    label {
      display: block;
      font-size: 0.72rem;
      font-weight: 600;
      letter-spacing: 0.09em;
      text-transform: uppercase;
      color: var(--muted);
      margin-bottom: 0.5rem;
    }

    input, select {
      width: 100%;
      background: rgba(255,255,255,0.04);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      color: #fff;
      font-family: 'DM Mono', monospace;
      font-size: 0.9rem;
      padding: 0.75rem 1rem;
      outline: none;
      transition: border-color .2s, box-shadow .2s;
      -webkit-appearance: none;
    }

    input::placeholder { color: rgba(255,255,255,0.2); }

    input:focus, select:focus {
      border-color: var(--blue);
      box-shadow: 0 0 0 3px rgba(45,63,231,0.25);
    }

    select { cursor: pointer; }
    select option { background: #1a2035; }

    /* IP auto-detect row */
    .ip-row { position: relative; }
    .ip-detect {
      position: absolute;
      right: 10px; top: 50%;
      transform: translateY(-50%);
      font-size: 0.65rem;
      font-family: 'DM Mono', monospace;
      color: var(--green);
      cursor: pointer;
      padding: 4px 8px;
      border-radius: 6px;
      background: rgba(62,230,143,0.08);
      border: 1px solid rgba(62,230,143,0.2);
      transition: background .15s;
      white-space: nowrap;
    }
    .ip-detect:hover { background: rgba(62,230,143,0.15); }

    /* ── Submit btn ───────────────────────────── */
    button[type="submit"] {
      width: 100%;
      background: var(--blue);
      color: #fff;
      border: none;
      border-radius: var(--radius);
      font-family: 'Sora', sans-serif;
      font-size: 0.9rem;
      font-weight: 600;
      padding: 0.85rem 1rem;
      cursor: pointer;
      letter-spacing: 0.02em;
      margin-top: 0.5rem;
      transition: filter .2s, transform .15s;
      position: relative;
      overflow: hidden;
    }

    button[type="submit"]:hover { filter: brightness(1.15); transform: translateY(-1px); }
    button[type="submit"]:active { transform: translateY(0); filter: brightness(0.95); }

    button[type="submit"]::after {
      content: '';
      position: absolute;
      inset: 0;
      background: linear-gradient(135deg, rgba(255,255,255,0.08) 0%, transparent 60%);
    }

    /* ── Alert states ─────────────────────────── */
    .alert {
      border-radius: var(--radius);
      padding: 0.9rem 1rem;
      font-size: 0.83rem;
      line-height: 1.5;
      margin-top: 1rem;
      display: none;
      font-family: 'DM Mono', monospace;
    }
    .alert.show { display: block; animation: fadeUp .3s ease both; }
    .alert-success {
      background: rgba(62,230,143,0.1);
      border: 1px solid rgba(62,230,143,0.3);
      color: var(--green);
    }
    .alert-error {
      background: rgba(231,72,72,0.1);
      border: 1px solid rgba(231,72,72,0.3);
      color: #f87171;
    }

    /* ── Footer ───────────────────────────────── */
    footer {
      margin-top: 1.5rem;
      text-align: center;
      font-family: 'DM Mono', monospace;
      font-size: 0.65rem;
      color: rgba(255,255,255,0.18);
      letter-spacing: 0.06em;
    }
  </style>
</head>
<body>

<div class="card">
  <div class="logo-wrap">
    <img src="data:image/png;base64,${LOGO_B64}" alt="entityOS">
  </div>

  <span class="badge">Space IP Logger</span>
  <h1>Register IP Address</h1>
  <p class="sub">Enter a valid Space ID and the IP address you want to record against that space.</p>

  <div class="divider"></div>

  <form id="ipForm" novalidate>
    <div class="field">
      <label for="spaceId">Space ID</label>
      <select id="spaceId" name="spaceId" required>
        <option value="" disabled selected>— select a space —</option>
        ${spacesListHtml}
      </select>
    </div>

    <div class="field">
      <label for="ipAddress">IP Address</label>
      <div class="ip-row">
        <input
          id="ipAddress"
          name="ipAddress"
          type="text"
          placeholder="e.g. 192.168.1.1"
          autocomplete="off"
          spellcheck="false"
          required
        />
        <span class="ip-detect" id="detectBtn">Detect mine ↗</span>
      </div>
    </div>

    <button type="submit">Record IP Address →</button>

    <div class="alert alert-success" id="successMsg"></div>
    <div class="alert alert-error"   id="errorMsg"></div>
  </form>
</div>

<footer>entityOS · Space IP Logger · v1.0</footer>

<script>
  const form       = document.getElementById('ipForm');
  const successMsg = document.getElementById('successMsg');
  const errorMsg   = document.getElementById('errorMsg');
  const detectBtn  = document.getElementById('detectBtn');
  const ipInput    = document.getElementById('ipAddress');

  detectBtn.addEventListener('click', async () => {
    detectBtn.textContent = 'detecting…';
    try {
      const r = await fetch('https://api.ipify.org?format=json');
      const d = await r.json();
      ipInput.value = d.ip;
    } catch {
      ipInput.value = '';
    }
    detectBtn.textContent = 'Detect mine ↗';
  });

  function showSuccess(msg) {
    successMsg.textContent = '✓ ' + msg;
    successMsg.classList.add('show');
    errorMsg.classList.remove('show');
  }
  function showError(msg) {
    errorMsg.textContent = '✕ ' + msg;
    errorMsg.classList.add('show');
    successMsg.classList.remove('show');
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    successMsg.classList.remove('show');
    errorMsg.classList.remove('show');

    const spaceId   = document.getElementById('spaceId').value.trim();
    const ipAddress = ipInput.value.trim();

    if (!spaceId)   return showError('Please select a Space ID.');
    if (!ipAddress) return showError('Please enter an IP address.');

    const btn = form.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.textContent = 'Recording…';

    try {
      const res = await fetch(window.location.href, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ spaceId, ipAddress }),
      });
      const data = await res.json();

      if (res.ok && data.success) {
        showSuccess(data.message || 'IP address recorded successfully.');
        form.reset();
      } else {
        showError(data.error || 'Something went wrong. Please try again.');
      }
    } catch {
      showError('Network error – unable to reach the server.');
    } finally {
      btn.disabled = false;
      btn.textContent = 'Record IP Address →';
    }
  });
</script>
</body>
</html>`;
}

// ── Route handlers ────────────────────────────────────────────────────────────
function handleGET() {
  const settings = loadSettings();
  const activeSpaces = settings.spaces.filter(s => s.active);

  return {
    statusCode: 200,
    headers: { 'Content-Type': 'text/html; charset=utf-8' },
    body: buildHTML(activeSpaces),
  };
}

function handlePOST(body) {
  let parsed;
  try {
    parsed = typeof body === 'string' ? JSON.parse(body) : body;
  } catch {
    return json(400, { success: false, error: 'Invalid JSON body.' });
  }

  const { spaceId, ipAddress } = parsed || {};

  if (!spaceId || !ipAddress) {
    return json(400, { success: false, error: 'Both spaceId and ipAddress are required.' });
  }

  if (!isValidGuid(spaceId)) {
    return json(400, { success: false, error: 'spaceId must be a valid GUID.' });
  }

  if (!isValidIP(ipAddress)) {
    return json(400, { success: false, error: 'ipAddress must be a valid IPv4 or IPv6 address.' });
  }

  // Validate against settings
  const settings = loadSettings();
  const space = settings.spaces.find(s => s.id.toLowerCase() === spaceId.toLowerCase());

  if (!space) {
    return json(403, { success: false, error: 'Space ID not found.' });
  }
  if (!space.active) {
    return json(403, { success: false, error: `Space "${space.name}" is inactive and not accepting records.` });
  }

  // Persist record
  const records = loadRecords();
  const record = {
    id: `rec_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    spaceId: space.id,
    spaceName: space.name,
    ipAddress,
    recordedAt: new Date().toISOString(),
  };
  records.push(record);
  saveRecords(records);

  return json(200, {
    success: true,
    message: `IP address ${ipAddress} recorded for space "${space.name}".`,
    record,
  });
}

function json(statusCode, obj) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(obj),
  };
}

// ── Lambda entry point ────────────────────────────────────────────────────────
exports.handler = async (event) => {
  const method = (event.httpMethod || event.requestContext?.http?.method || 'GET').toUpperCase();

  try {
    if (method === 'GET') {
      return handleGET();
    }
    if (method === 'POST') {
      return handlePOST(event.body);
    }
    return json(405, { success: false, error: `Method ${method} not allowed.` });
  } catch (err) {
    console.error('Unhandled error:', err);
    return json(500, { success: false, error: 'Internal server error.' });
  }
};
